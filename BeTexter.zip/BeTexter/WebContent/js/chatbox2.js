
var xmlHttpForLogOut = createHttpRequestObjectForSender();

function displayReceiverMessage(message,belowDiv,userid,date)
	{
		if(!(message===undefined))
		 {
			var temp = message.trim();
		 	if(message!="noNewMessages" && message!="nomessages" &&  temp!="" && message!="error" && temp!="nomessages" && temp!="error" && temp!=",")
		 	{
		 			if(belowDiv==false)
		 			{
		 				var id = "placeRecentMessages"+userid;
		 				var h = document.getElementById(id);
		 				h.insertAdjacentHTML("beforebegin",'<p>'+userid+" : "+message+'</p><br><p style="font-size: 10px; color: grey;">'+date+'</p></div>');
		 			}
		 			else
		 			{
		 				var id = "placeMessagesHere"+userid;
		 				var h = document.getElementById(id);
		 				h.insertAdjacentHTML("afterend", '<p>'+userid+" : "+message+'</p><br><p style="font-size: 10px; color: grey;">'+date+'</p></div>');
		 			}
		 	}
		 }
	}

	
// displaying the user message and sending to the database
function displayMessageAndSend(userid)
	 {
    	var message = document.getElementById("messageToBeSent"+userid).value;
    	document.getElementById("messageToBeSent"+userid).innerHTML="";
    	var a = new Date();
    
    	displayUserMessage(message,false,userid,a);// live sending message 
    	sendMessage(userid,message);
	}
	 

	 
	 
function displayUserMessage(message,belowTheDiv,userid,date)
	{
		 var temp = message.trim();
		 
		 if(message!="noNewMessages" && message!="nomessages" && message!="" && message!="error" && temp!="nomessages" && temp!="error")
			 {
			 	if(belowTheDiv==false)
			 	{
			 		var id ="placeRecentMessages"+userid;
			 		var h = document.getElementById(id);
			 		h.insertAdjacentHTML("beforebegin",'<p>'+"you :"+message+'<br><p style="font-size: 10px; color: grey;">'+date+'</p></p></div>');
			 	}
			 	else
			 	{
			 		var id ="placeMessagesHere"+userid;
			 		
			 		var h = document.getElementById(id);
			 		h.insertAdjacentHTML("afterend",'<p>'+"you :"+message+'<br><p style="font-size: 10px; color: grey;">'+date+'</p></p></div>');
			 	}
			 }
	 
	 }

var xmlHttpForSender = createHttpRequestObjectForSender();
	 
	 // for sending messages....
function sendMessage(receivername,message)
	{
		 if(xmlHttpForSender.readyState==4 || xmlHttpForSender.readyState==0)
		   {
			 	message = encodeURIComponent(message);
		   
			 	try
			 	{
			 		xmlHttpForSender.onreadystatechange = handleServerRequest;
			 		var url = "SenderMessageReceiver.jsp?receivername="+receivername+"&message="+message;
			 		xmlHttpForSender.open("GET",url,true);
			 		xmlHttpForSender.send();
		  
			 	}
			 	catch(e)
			 	{
			 		alert(e);
			 	}
		   }
	   
	   else
		   {
		   //alert("unable to connect to server! at present");
		     setTimeout('sendMessage()',1000);
		   
		   }
     }

// handing the response from the server for sending the messages
function handleServerRequest()
	 {

	   if(xmlHttpForSender.readyState==4)
		   {
		   		var result = xmlHttpForSender.responseText;
	       		if(result=="failure")
	       		{
	       			alert("Error in sending message");
	       		}
	     
		   }
	  


	 }
	 // creating the xml object

function createHttpRequestObjectForSender()
	{
	    
	    if(window.XMLHttpRequest)
	    {
	  return new XMLHttpRequest();
	    }  
	    else if(window.ActiveXObject)
	    {
	    	return new ActiveXObject("Microsoft.XMLHTTP");
	    }
	    else
		   alert("Your browser is not supportive to the application");
		
	}
	 

	 
	 //logging out
function logout(isregularLogout)
	{
		var regularLogout = "false";
		if(isregularLogout==true)
			{
				alert("Logged Out");
				setCookies("username","@123");
				sessionStorage.clear();
				regularLogout="true";
			}
		if(xmlHttpForLogOut.readyState==4 || xmlHttpForLogOut.readyState==0)
			{
				try
				{
					xmlHttpForLogOut.onreadystatechange =handleResponseFromDb;
					var url = "ClearCache.jsp?regularLogout="+regularLogout;
	   
					xmlHttpForLogOut.open("GET",url,true);
					xmlHttpForLogOut.send();
				}
				catch(e)
				{
					alert(e);
				}
			}
   
		else
			{
				//	alert("unable to connect to server! at present");
		 		setTimeout('logout ()',1000);
			}
		 	
		 	
		window.location="http://localhost:8080/BeTexter/";
	}	


// handling the response from db for logging out
function handleResponseFromDb()
	{
		if(xmlHttpForLogOut.readyState==4)
		 {
			if(xmlHttpForLogOut.status==200)
			 	{
				 	var result = xmlHttpForLogOut.responseText;
     			 	if(result=="failure")
     			 	{
     			 		//alert("Server problem!!");
				 	}
			 	}
				 
		 }
		else
			 {
			setTimeout('logout ()',1000);
			 }
     
	}
		
	 
	 
	 



