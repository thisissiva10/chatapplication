var xmlHttp=createHttpRequestObject();
var current_available="";
// fetching older messages
function process(idOfUser)
	{
		if(xmlHttp.readyState==4 || xmlHttp.readyState==0)
		{
			try
			{
				var start = sessionStorage.getItem(idOfUser+"start");
	   
				xmlHttp.open("GET","chatmanager.jsp?receivername="+idOfUser+"&start="+start,true);
  
				xmlHttp.onreadystatechange = handleServerResponse;
   
				xmlHttp.send();
			}
			catch(e)
			{
	   		//alert("unable to connect to server!");
			}
		}

		else
		{
	 	//alert("unable to hit the server");
			setTimeout("process('"+idOfUser+"')",1000);
        }
    }

function handleServerResponse()
{
	if(xmlHttp.readyState==4)
	{
		if(xmlHttp.status==200)
		{
			displayReceivedMessage(xmlHttp.responseText);  			   
		}
	}
}
   
function displayReceivedMessage(MessageFromDatabase)
   {
		var json = JSON.parse(MessageFromDatabase);
		sessionStorage.setItem(sessionStorage.getItem("activeid"),"true");
		if(json.status=="true")
		{
			sessionStorage.setItem(sessionStorage.getItem("activeid"),"true");
		}
		else
		{
			sessionStorage.setItem(sessionStorage.getItem("activeid"),"false");
		}
 
   
		var username = json.username;
		var receivername = json.receivername;
		var message = json.message;
		var datetime = json.datetime;
		var i =0;
		for(var name in username)
		{
			var index = "a"+i.toString();
			
			var key = makeKey(username[index],receivername[index]);
			var limit = key.indexOf("@!@#$%^&*()_+");
			if(limit!=-1)
			{
				
				displayReceiverMessage(message[index],true,sessionStorage.getItem("activeid"),datetime[index]);     
			}
			else
			{
				displayUserMessage(message[index],true,sessionStorage.getItem("activeid"),datetime[index]);
            }
			i=i+1;
        }
  }


   
   
function createHttpRequestObject()
	{
	   var object;
	   if(window.XMLHttpRequest)
	   	{  
		   object=new XMLHttpRequest();  
	   	}  
	   else if(window.ActiveXObject)
	   	{  
		   object=new ActiveXObject("Microsoft.XMLHTTP");  
   	}
   else
	 {
	   object = false;
	 }
   
   
   if(object==false)
	   alert("Your browser is not supportive to the application");
		else 
			{
			return object;
			}
		
  }


function makeKey(name1,name2)
   {
	   var res=name1.localeCompare(name2);
	   if(res>0)
   			{
		   		return name1+"&"+name2;
   			}
	   else
   			{
	   		return name2+"&"+name1+"@!@#$%^&*()_+";
	   		}            
   }
