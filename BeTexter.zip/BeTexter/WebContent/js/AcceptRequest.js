
var acceptReq = createAcceptRequest();

function acceptRequest(fromuser)
{
if(acceptRequest!=false)
	{
	sessionStorage.setItem("fromuser","'"+fromuser+"'");

	if(acceptReq.readyState==4 || acceptReq.readyState==0)
		{
		try
			{
				var url = "AcceptRequest.jsp?fromuser="+fromuser;
				acceptReq.onreadystatechange=handleAcceptRequest;
				acceptReq.open("GET",url,true);
				acceptReq.send();
				 
			}
		catch(e)
			{
				alert(e);
			}
		}
	
	}
}


function handleAcceptRequest()
{
	
if(acceptReq.readyState==4)
	{
	
	if(acceptReq.status==200)
	{
		
		var result = acceptReq.responseText;
		
		var parsing= result.split("<body>");
		var parsing2 = parsing[1].split("</body>");
		
		if(parsing2[0].trim()=="success")
			displayFriendList();
		
	}
	
	}

}

function createAcceptRequest()
{
	if(window.XMLHttpRequest)
	{  
			return new XMLHttpRequest();  
	}  
	else if(window.ActiveXObject)
		{  
		 	return new ActiveXObject("Microsoft.XMLHTTP");  
		}
	else
		 	return false;
}