var friendreq = createFriendReq();
function addFriend(touser)
{
	sessionStorage.setItem("touser","'"+touser+"'");
	if(friendreq!=false)
      {
		
		if(friendreq.readyState==4 || friendreq.readyState==0)
			{
			try
			  {
				  var url = "AddFriend.jsp?touser="+touser;
				  friendreq.open("GET",url,true);
				  friendreq.onreadystatechange=handleFriendRequest;
				  friendreq.send();
				  
			  }
			  catch(e)
			  {
				  alert(e);
              }
			
			}
		
		
      }
	}

function handleFriendRequest()
{
	

	if(friendreq.readyState==4)
		{
		
		if(friendreq.status==200)
			{
				/*var result = friendreq.responseText;
				var parsing = result.split("<body>");
				var parsing2 = parsing[1].split("</body>");
				
				console.log(parsing2[0].trim());*/
			}
		
		}
	
	}



function createFriendReq()
{
if(window.XMLHttpRequest)
{  
		return new XMLHttpRequest();  
}  
else if(window.ActiveXObject)
	{  
	 	return new ActiveXObject("Microsoft.XMLHTTP");  
	}
else
	 	return false;
}