

var reqconfirm = createReqConfirm();

function checkForRequestAcceptance()
{
	
	if(reqconfirm!=false){

	if(reqconfirm.readyState==4 || reqconfirm.readyState==0)
		{
		try
			{
				var url = "checkForAcceptance.jsp";
				reqconfirm.onreadystatechange=handleAcceptanceResponse;
				reqconfirm.open("GET",url,true);
				reqconfirm.send();
			}
		catch(e)
			{
			alert(e);
			}
		
		}
	else
	   {
	 
	     setTimeout('checkForRequestAcceptance()',5000);
	   
	   }
	}
	else
		{
		alert("Your browser is not supportive ");
		}
}

function handleAcceptanceResponse()
{
	
	if(reqconfirm!=false)
		{
		if(reqconfirm.readyState==4)
		{
	
			if(reqconfirm.status==200)
			{
		
				 var result =reqconfirm.responseText;
				 var parsing = result.split("<body>");
				 var parsing2 = parsing[1].split("</body>");
				 var reply = parsing2[0].trim();
				 
				 if(reply=="yes")
					 {
					 displayFriendList();
					 }
			}
	
		}
		else
		{

			setTimeout('checkForRequestAcceptance()',5000);

		}

		}
	else
		{
		alert("Your browser is not supportive ");
		}
		
}


function createReqConfirm()
{
	
	if(window.XMLHttpRequest)
	{  
			return new XMLHttpRequest();  
	}  
	else if(window.ActiveXObject)
		{  
		 	return new ActiveXObject("Microsoft.XMLHTTP");  
		}
	else
		 	return false;


}
