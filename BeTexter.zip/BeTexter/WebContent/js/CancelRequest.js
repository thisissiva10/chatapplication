var cancelreq = createCancelReq();


function cancelRequest(touser)
{
	

	sessionStorage.setItem("canceluser","'"+touser+"'");
	if(cancelreq!=false)
		{
		
		if(cancelreq.readyState==4 || cancelreq.readyState==0)
			{
			
			try
			{
				var url = "CancelReq.jsp?touser="+touser;
				cancelreq.onreadystatechange=handleCancelRequest;
				cancelreq.open("GET",url,true);
				cancelreq.send();
					
			}
			catch(e)
			{
				alert(e);
			}
			}
		}
	else
		{
		alert("Browser is not supportive");
		}
}


function handleCancelRequest()
{
	
if(cancelreq.readyState==4)
	{
	if(cancelreq.status==200)
		{
		
		var result = cancelreq.responseText;
		var parsing= result.split("<body>");
		var parsing2 = parsing[1].split("</body>");
		
		
		if(parsing2[0].trim()=="success")
			displayFriendList();
		}
	
	}
else
	{
	
	setTimeout("cancelRequest("+sessionStorage.getItem("canceluser")+")",9000);
	
	}
	

}
function createCancelReq()
{
	if(window.XMLHttpRequest)
	{  
			return new XMLHttpRequest();  
	}  
	else if(window.ActiveXObject)
		{  
		 	return new ActiveXObject("Microsoft.XMLHTTP");  
		}
	else
		 	return false;
}



