   var message_count = new Map();
  
   var xmlHttpForLive = createHttpObjectForLiveChat();

   // for tail loading 
      function hasToLoadFurther(id)
       {
            
        	var loc = document.getElementById(id);
        	var x = loc.scrollTop;
        	var furtherToLoad = sessionStorage.getItem(sessionStorage.getItem('activeid'));
        	if(x==0 && furtherToLoad=="true")
        		{
        			var start = sessionStorage.getItem(id+"start");
        			sessionStorage.setItem(id+"start",start+20);
        			process(id);
        		}
       }
        
        //sending the request to the server

        function getTheLiveMessage(id)
        {
        	
        	var idOfUser=id;//sessionStorage.getItem("activeid");
        	
       	 if(xmlHttpForLive.readyState==4 || xmlHttpForLive.readyState==0)
		   {
		   try{
			   xmlHttpForLive.open("GET","GetLive.jsp?receivername="+idOfUser,true);
			   xmlHttpForLive.onreadystatechange = handleLiveChatResponse;
		      xmlHttpForLive.send();
		      sessionStorage.setItem("previousid",idOfUser);
		      }
		   catch(e)
		   {
			   
			   alert("unable to connect to server! "+e);
		   }
		   }
	    
	   else
		   {
		 // alert("unable to hit the server");
		     setTimeout("getTheLiveMessage('"+idOfUser+"')",5000);
		     }
        }
        
        
        function handleLiveChatResponse()
        {
        	if(xmlHttpForLive.readyState==4)
        		{
        		
        		if(xmlHttpForLive.status==200)
        			{
        				var MessageFromDatabase = xmlHttpForLive.responseText;
                        var temp = MessageFromDatabase.trim();
                         if(temp=="error")
                         {
                            //alert("Error !!! Try after sometime");
                         }   
                         else if(temp=="noNewMessages"|| temp === undefined || temp==null || temp=="nomessages")
                         {

                            setTimeout("getTheLiveMessage('"+sessionStorage.getItem("previousid")+"')",5000);

                         }
                         else
                         {
                             var json = JSON.parse(MessageFromDatabase);
                             var message = json.message;
                             var datetime = json.datetime;
                             var i=0;
                             var index = "a"+i.toString();
                             for(var keys in message)
                             {

                                displayReceiverMessage(message[index],false,sessionStorage.getItem("previousid"),datetime[index]);
                                i=i+1;
                                index = "a"+i.toString();
                             }
                         }
        			}
        		
        		}
        	
        	setTimeout("getTheLiveMessage('"+sessionStorage.getItem("previousid")+"')",5000);
        	
       }
        
        function createHttpObjectForLiveChat()
        {
        	
     	   var object;
    	   if(window.XMLHttpRequest)
    	   {  
    	  object=new XMLHttpRequest();  
    	   }  
    	 else if(window.ActiveXObject){  
          object=new ActiveXObject("Microsoft.XMLHTTP");  
          }
    	 else
    		 {
    		 object = false;
    		 }
    	   
    	   
    	   if(object==false)
    		   alert("Cant connect to server!!  Try Again after some time");
    		else 
    			{
    			
    	        return object;
    			}
    			
        }
        
        
      // processing the new unseen messages...
        
        
        function showNewMessages(newMessages)
        {
        	//alert(newMessages);
        	var temp = newMessages.trim();
        	if(temp!="error" && temp!="connectionerror" &&temp!="nomessages" && temp!="noNewMessages")
        		{
        		
        		var various_messages = newMessages.split("\n");
        		for(var i=0;i<various_messages.length;i++)
        			{
        			
        			 var record = various_messages[i].split(" : ");
        			 var user = record[0];
        			 var message = record[1];
        			 
        			 if(message_count.has(user))
        				 {
        				 var count = message_count.get(user);
        				 message_count.set(user,count+1);
        				 }
        			 else
        				 {
        				 
        				 message_count.set(user,1);
        				 
        				 }
        			}
        		displayNewMessageCount();
        		}
        	
        }
        
        // displaying the count of new messages...
        function displayNewMessageCount()
        {
        	message_count.forEach(function (value, key, mapObj) 
        			{
        			/*if(value!=0)
        					{
        				
        				var count_pos = "count_";
        				count_pos = count_pos+key;
        					var count = document.getElementById(count_pos);
        					count.insertAdjacentHTML('beforeend','<p>'+value+'</p>');
        					
        					}*/
        			}); 
        	
        }
        
        
        