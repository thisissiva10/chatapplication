

var incoming_message_count = new Map();
var incomingHttp = createHttpForIncoming();

function incomingMessages()
{

	if(incomingHttp.readyState==0 || incomingHttp.readyState==4)
		{
		
		try{
			   
			incomingHttp.open("GET","GetIncomingMessages.jsp",true);
			incomingHttp.onreadystatechange = handleIncomingResponse;
			incomingHttp.send();
		   }
		catch(e)
		   {
			   
			   alert("unable to connect to server! "+e);
		   }
		}
	else
	   {
	 // alert("unable to hit the server");
	     setTimeout('incomingMessages()',5000);
	   
	   }
	
}	

function handleIncomingResponse()
{
	if(incomingHttp.readyState==4)
		{
		
		if(incomingHttp.status==200)
			{
			
			
				var json = JSON.parse( incomingHttp.responseText);
				
				var username = json.username;
				
				for(var key in username)
				{

					if(!(username[key]===undefined) && username[key]!=sessionStorage.getItem("activeid"))
		        	  {
		        	  		var tempId = "count_";
		        	    	tempId = tempId + key.trim();
		        	      	var loc = document.getElementById(tempId);
		        	        var dis = "unread messages : "+username[key];
		        	    	  loc.innerHTML=dis;
		        	  }

				}
		    displayOnlineStatus(json.onlineusers,json.onlinestatus);
			}
		}
	else
		{
		setTimeout('incomingMessages()',5000);
		}

}

function displayOnlineStatus(onlineUsers,onlinestatus)
{

	for(var keys in onlineUsers)
	{
	
			var id = "status";
			id = id + onlineUsers[keys];
			var login = onlinestatus[keys];
			
			
			
			if(login==1)
				{
				document.getElementById(id).style.background="GREEN";
				document.getElementById(id).style.width="10px";
				document.getElementById(id).style.height="10px";
				document.getElementById(id).style.borderRadius="40%";
				document.getElementById(id).style.display="inline-block";
				
				}
			else
				{
				document.getElementById(id).style.background="BLUE";
				document.getElementById(id).style.width="10px";
				document.getElementById(id).style.height="10px";
				document.getElementById(id).style.borderRadius="40%";
				document.getElementById(id).style.display="inline-block";
			
			}

	}


}


function createHttpForIncoming()
{
	if(window.XMLHttpRequest)
	   {  
			return new XMLHttpRequest();  
	   }  
	 else if(window.ActiveXObject)
	 	{  
		 	return new ActiveXObject("Microsoft.XMLHTTP");  
	 	}
	 else
		 	return false;

}
