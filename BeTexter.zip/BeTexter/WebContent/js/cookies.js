
function getCookies(key)
{
	var allcookies = document.cookie;
	var cookiearray = allcookies.split(';');

	for(var i=0; i<cookiearray.length; i++)
	{
		var name = cookiearray[i].split('=')[0];
	
		if(name==key)
			{
			return cookiearray[i].split('=')[1];
			
			}
	}

	return "null";
}


function setCookies(key,value)
{
	document.cookie = key+"="+value;

}


