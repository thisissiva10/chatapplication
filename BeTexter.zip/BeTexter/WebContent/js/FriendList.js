

var userList = createUserListObject();


function displayFriendList()
{
		if(userList!=false)
			{
			if(userList.readyState==4 || userList.readyState==0)
				{
				try
				{
					var url = "GetListOfUsers.jsp";
					userList.onreadystatechange=handleFriendListResponse;
					userList.open("GET",url,true);
					userList.send();
				}
				catch(e)
				{
					alert(e);
				}
				
				}
			else
			   {
			 // alert("unable to hit the server");
			     setTimeout("displayFriendList()",5000);
			     }
			}
		else
			{
			alert("BROWSER IS NOT SUPPORTIVE");
			}
		
	
}
function handleFriendListResponse()
{
	if(userList.readyState==4)
		{
		
		if(userList.status==200)
			{
			//var evaluate = eval( "(" + jsonString + ")" );
			var json = JSON.parse(userList.responseText);
			
			showFriendsList(json.friendList);
			
			showOtherList(json.otherlist);
			showRequestList(json.requestlist);

			}
		}

}


function showFriendsList(friends)
{
	if(!(friends===undefined))
		{
			var loc = document.getElementById("nameListt1");
			var temp='<div class="nameList" id="nameList">';
			loc.innerHTML=temp;
			var count =  friends.length; 
			loc = document.getElementById("nameList");
			for(var keys in friends)
				{
					var username = friends[keys];
					var count_id = "count_"+username;
					var status = "status"+username;
					
					var element  = ' <div class="name">';
					element = element + '<div id="'+status+'"></div>';
					element = element + '<a href="javascript:register_popup(\''+ username +'\',\''+ username +'\');"><span style="margin-left:10px;">'+username+'</span></p></a>';
					element = element+'<div class="cancelbutton">';
					element  = element + '<button class="css-button" onclick="cancelRequest(\''+ username +'\' )">Cancel Request</button></div></div>';
					element = element +'<p id="'+count_id+'" > unread messages : 0';
					loc.insertAdjacentHTML('afterend',element);
					 
				}
		}
}

function showOtherList(others)
{
	if(!(others===undefined))
	{

		var loc = document.getElementById("nameListt2");
		var temp = '<div class="nameList2" id="nameList2">';
		loc.innerHTML=temp;
		var count =  Object.keys(others).length;
		loc = document.getElementById("nameList2");
		for(var keys in others)
		   {
			var username = others[keys];
			var element  = '<div class="name">';
			element = element + '<span>'+username+'</span>';
			element = element + '<div class="cancelbutton">';
			element = element + '<button class = "css-button"  onclick="addFriend(\''+ username +'\')" id="button"'+username+'">Add Friend</button></div></div>';
			loc.insertAdjacentHTML('afterend',element);
			}
	}
	
}

function showRequestList(requests)
{
	if(!(requests===undefined))
	{

		var loc = document.getElementById("nameListt3");
		var temp = '<div class="nameList3" id="nameList3">';
		loc.innerHTML=temp;
		var count =  Object.keys(requests).length;
		loc = document.getElementById("nameList3");
		for(var keys in requests)
		{
			var username = requests[keys];

			var element = '<div class="name">';
			element = element +'<span>'+username+'</span>';
			element = element + '<div class="request">';
			element = element +'<button class = "css-button" onclick="acceptRequest(\''+ username +'\')" id="button"'+username+'">Accept Request</button></div></div>';
			loc.insertAdjacentHTML('afterend',element);
		}
	}
}


function showOnlineStatus(username,login)
{
	
	  var id = "status";
		 id = id+username;
		 var styles =document.getElementById(id);
		 styles.style.width= "12px";
		 styles.style.height=" 12px";
		    
	        
	     if(login=="true")
	    	 {
	    	 styles.style.background="GREEN"; 
	         }
	     else
	    	 {
	    	 styles.style.background="BLUE";
	    	 }
	   

}

function showIncomingMsgs(username)
{
	var count ="count_";
	 count = count+username;
	 var apply = document.getElementById(count);
	 apply.style.position="relative";
	 apply.style.marginBottom="10px";
}
function createUserListObject()
{
	
	if(window.XMLHttpRequest)
	{  
			return new XMLHttpRequest();  
	}  
	else if(window.ActiveXObject)
		{  
		 	return new ActiveXObject("Microsoft.XMLHTTP");  
		}
	else
		 	return false;
}