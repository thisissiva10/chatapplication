package texter;
import java.sql.Connection;

import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;
public class AddFriend 
{

	public String addFriend(String touser)
	{
		HttpSession sessionObject=ServletActionContext.getRequest().getSession(false); 
		String sendername = String.valueOf(sessionObject.getAttribute("username"));
		sendername = "'"+sendername+"'";
		
		try
		{
			
	    final Connection con = new ConnectionManager().getConnection();
		touser = "'"+touser+"'";
		java.sql.Statement st = con.createStatement();
		
		String sql ="SELECT COUNT(sendername) from request WHERE sendername = "+sendername+" AND receivername = "+touser+" ;";
		java.sql.ResultSet rs = st.executeQuery(sql);
		int count = -1;
		while(rs.next())
		{
			count = Integer.parseInt(rs.getString(1));
		}
		if(count==0)
		{
			sql ="INSERT INTO request VALUES("+sendername+","+touser+");";
			st.execute(sql);
			sql = "UPDATE users set notify = true where username ="+touser+";";
			st.execute(sql);
		}
		con.close();
		return "success";
		}
		catch(Exception e)
		{
			System.out.println(e);
			return "failure";
		}
		
	}
	

}
