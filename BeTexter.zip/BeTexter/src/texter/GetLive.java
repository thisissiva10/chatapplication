package texter;

import java.sql.Connection;
import org.json.JSONObject;

import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

public class GetLive 
{
	public String getLive(String receivername)
	{
		try
			{
				HttpSession session=ServletActionContext.getRequest().getSession(false); 
				String username = String.valueOf(session.getAttribute("username"));
				username ="'"+username+"'";
				receivername="'"+receivername+"'";
				Connection con = new ConnectionManager().getConnection();
				java.sql.Statement st = con.createStatement();
				JSONObject  message = new JSONObject();
				JSONObject  datetime = new JSONObject();
				JSONObject  bundle = new JSONObject();
				String max_id="";
				String sql = "SELECT MAX(ID) from message where incoming=false AND ((receivername = "+receivername+" AND username = "+username+") OR (receivername = "+username+" AND username = "+receivername+"));";
				java.sql.ResultSet rs = st.executeQuery(sql);
				while(rs.next())
					{
					max_id=rs.getString(1);
					}
				if(max_id!="")
					{
					
					if(max_id==null)
						max_id="0";
					
					//System.out.println(max_id);
					int id = Integer.parseInt(max_id);
						sql = "SELECT message,datetime FROM message WHERE incoming=true AND ID  > "+id+" AND username = "+receivername+" AND receivername = "+username+";";
						rs = st.executeQuery(sql);
						int i=0;
						String temp="";
						while(rs.next())
						{
					
							temp="a"+String.valueOf(i);
							//list.add(rs.getString(1)+" : "+rs.getString(2));
							message.put(temp,rs.getString(1));
							datetime.put(temp,rs.getString(2));
							i++;

					
						}
				
						if(i==0)
						{
						
							con.close();
							return "nomessages";
							
						}
						else
						{
							
							//System.out.println("The live messages for You from this receiver is: "+list);
							sql = "UPDATE message SET incoming=false WHERE  ID  > "+id+" AND username = "+receivername+" AND receivername = "+username+";";
							st.execute(sql);
							con.close();
							bundle.put("message",message);
							bundle.put("datetime",datetime);

							return bundle.toString();
						}
					
				  }
				con.close();
				return "nomessages";
				
				}
				catch(Exception e)
				{
					System.out.println(e.toString()+" get live");
					return "error";
				}
				
			}
		
			
		
		
	
	
	
	}



