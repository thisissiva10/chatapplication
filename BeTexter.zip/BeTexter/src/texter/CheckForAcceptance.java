package texter;

import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

public class CheckForAcceptance 
{
	
	
	public String checkForAcceptance()
	{
		
		HttpSession sessionObject=ServletActionContext.getRequest().getSession(false); 
		String sendername = String.valueOf(sessionObject.getAttribute("username"));
		sendername = "'"+sendername+"'";
		
		try
		{
			
			// checking for new acceptance.....
			java.sql.Connection con = new ConnectionManager().getConnection();
			java.sql.Statement st = con.createStatement();
			String sql = "SELECT notify from users where username = "+sendername+";";
			
			java.sql.ResultSet rs = st.executeQuery(sql);
			String count="0";
			while(rs.next())
				count = rs.getString(1);
			
			if(count.equals("1"))
			{
				sql = "UPDATE users set notify = false where username = "+sendername+";";
				st.execute(sql);
				con.close();
				//System.out.println("yes");
				return "yes";
			}
			
			con.close();
			//System.out.println("no");
			return "no";
		}
		catch(Exception e)
		{
			System.out.println(e+"CFA");
			return "no";
		}
		
		
	}

}
