package texter;

import java.sql.Connection;

import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

public class ResetUserRecords
{
	
	public String clearCache(String regularLogout)
	{
		try
		{
			HttpSession session=ServletActionContext.getRequest().getSession(false); 
			String username = String.valueOf(session.getAttribute("username"));
			username = "'"+username+"'";
			Connection con = new ConnectionManager().getConnection();
			java.sql.Statement st = con.createStatement();
			String sql ="UPDATE users SET login = false WHERE username = "+username+";";
			st.execute(sql);
 		   con.close();
		   if(regularLogout.equals("true"))
		   {
		   session.removeAttribute("username");
		   
		   }
			return "successful";
		}
		catch(Exception e)
		{
			System.out.println(e+"Logout");
			return "failure";
		}
	}

}
