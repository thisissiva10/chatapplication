package texter;

import java.sql.Connection;
import org.json.JSONObject;
import javax.servlet.http.HttpSession;
import org.apache.struts2.ServletActionContext;

public class GetIncomingMessages 
{

	private final Connection con = new ConnectionManager().getConnection();
	
	
	public String getIncomingMessages()
	{
		HttpSession sessionObject=ServletActionContext.getRequest().getSession(false); 
		String sendername = String.valueOf(sessionObject.getAttribute("username"));
		sendername = "'"+sendername+"'";
		JSONObject  username = new JSONObject();
		JSONObject  onlinestatus = new JSONObject();
		JSONObject  onlineusers = new JSONObject();
		JSONObject  bundle = new JSONObject();
		StringBuilder usersbuilder=new StringBuilder();
		
		try
			{
			java.sql.Statement st = con.createStatement();
			String sql = "select receivername from friend where sendername  = "+sendername+" ;";
			java.sql.ResultSet rs = st.executeQuery(sql);

				while(rs.next())
				{
					usersbuilder.append(rs.getString(1)+",");
				
				}
				String temp="";
				String builderArray[] = usersbuilder.toString().split(",");
				for(int i=0;i<builderArray.length;i++)
				{
					temp="'"+builderArray[i]+"'";
					sql = "SELECT COUNT(username) FROM message where username = "+temp+" AND receivername="+sendername+" AND incoming = true;";
					rs = st.executeQuery(sql);
					while(rs.next())
					{
						username.put(builderArray[i],rs.getString(1));
					}
				}


			sql ="SELECT username,login from users where (not username ="+sendername+") AND username in (select receivername from friend where sendername  = "+sendername+") ;";
			rs=st.executeQuery(sql);

			while(rs.next())
			{
				onlinestatus.put(rs.getString(1),rs.getString(2));
				onlineusers.put(rs.getString(1),rs.getString(1));
			}
		
			con.close();

			bundle.put("username",username);
			bundle.put("onlinestatus",onlinestatus);
			bundle.put("onlineusers",onlineusers);
			

			return bundle.toString();
				
			}
			catch(Exception e)
			{
				System.out.println(e);
				return "error";
			}
		
	}
	
	
			
	
}
