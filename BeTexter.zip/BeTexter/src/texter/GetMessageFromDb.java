package texter;
import java.sql.Connection;

import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;
import org.json.JSONObject;

public class GetMessageFromDb 
{
	private final Connection con = new ConnectionManager().getConnection(); 

	public String getMessageFromDatabase(String receivername,String start)
	{
		
		//System.out.println("finally getting from db bro");
		
		//List<String> list = new java.util.ArrayList<String>();
		JSONObject username = new JSONObject();
		JSONObject rname = new JSONObject();
		JSONObject message = new JSONObject();
		JSONObject datetime = new JSONObject();
		JSONObject status  = new JSONObject();

		JSONObject bundle  = new JSONObject();


		HttpSession session=ServletActionContext.getRequest().getSession(false); 
		String sendername = String.valueOf(session.getAttribute("username"));
		sendername ="'"+sendername+"'";
		receivername = "'"+receivername+"'"; 
		int start_range = Integer.parseInt(start);
		int count=0;
		try
		{
			
			java.sql.Statement st = con.createStatement();
			String sql = "SELECT username,message,receivername,datetime FROM message WHERE (( username = "+sendername+" AND receivername = "+receivername+" ) OR ( username = "+receivername+" AND receivername = "+sendername+")) ORDER BY ID DESC LIMIT "+start_range+",20;";
			java.sql.ResultSet rs = st.executeQuery(sql);
			int i=0;
			while(rs.next())
			{
				//list.add(rs.getString(1)+" : "+rs.getString(3)+" : "+rs.getString(2)+" : "+rs.getString(4));
				String value = String.valueOf(i);
				username.put("a"+value,rs.getString(1));
				message.put("a"+value,rs.getString(2));
				rname.put("a"+value,rs.getString(3));
				datetime.put("a"+value,rs.getString(4));
				
				
          		i++;
			}
			sql = "SELECT COUNT(ID) FROM message WHERE (( username = "+sendername+" AND receivername = "+receivername+" ) OR ( username = "+receivername+" AND receivername = "+sendername+")) ORDER BY ID DESC LIMIT "+start_range+",20;";
			rs = st.executeQuery(sql);
			while(rs.next())
			{
				count = Integer.parseInt(rs.getString(1));
			}
			
			
			if(count==20)
			{
				status.put("status","true");
			}
			else
			{
				status.put("status","false");
			}

			bundle.put("username",username);
			bundle.put("message",message);
			bundle.put("receivername",rname);
			bundle.put("datetime",datetime);
			bundle.put("status",status);
			
			  con.close();
			
			  return bundle.toString();
			
		}
		catch(Exception e)
		{
			
			System.out.println(e+"   GetMessagesFrom Db");
			return "error";
			
		}
	}

	
}
