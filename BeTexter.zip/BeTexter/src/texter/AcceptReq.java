package texter;

import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

public class AcceptReq 
{
	
	
	public String acceptReq(String toUser)
	{
		toUser = "'"+toUser+"'";
		HttpSession sessionObject=ServletActionContext.getRequest().getSession(false); 
		String sendername = String.valueOf(sessionObject.getAttribute("username"));
		sendername = "'"+sendername+"'";
	
		
		try
		{
			
			final java.sql.Connection con = new ConnectionManager().getConnection();
			java.sql.Statement st = con.createStatement();
			String sql = "DELETE FROM request WHERE (sendername = "+toUser+" AND receivername = "+sendername+") OR (sendername = "+sendername+" AND receivername = "+toUser+");";
			st.execute(sql);
			sql = "INSERT INTO friend values("+toUser+","+sendername+")";
			st.execute(sql);
			sql = "INSERT INTO friend values("+sendername+","+toUser+")";
			st.execute(sql);
			sql = "UPDATE users SET notify = true where username in ("+toUser+","+sendername+");";
			st.execute(sql);
			
			con.close();
			return "success";
		}
		catch(Exception e)
		{
			System.out.println(e);
			return "failure";
			
		}
		
		
	}

}
