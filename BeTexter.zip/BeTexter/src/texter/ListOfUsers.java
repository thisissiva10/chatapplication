package texter;

import java.sql.Connection;
import javax.servlet.http.HttpSession;
import org.apache.struts2.ServletActionContext;
import org.json.JSONObject;

public class ListOfUsers 
{
	

	public String getUsers()
	{
		JSONObject friendlist = new JSONObject();
		
		JSONObject otherlist = new JSONObject();
		JSONObject requestlist = new JSONObject();
		JSONObject  listOfUser = new JSONObject();
		
		HttpSession session=ServletActionContext.getRequest().getSession(false); 
		String sendername = String.valueOf(session.getAttribute("username"));
		
		
		
		try
		{
		
			sendername = "'"+sendername+"'";
			Connection con = new ConnectionManager().getConnection();
			java.sql.Statement st = con.createStatement();
			
			int i=0;
		String sql = "SELECT username FROM users where username in (Select receivername from friend where sendername = "+sendername+");";
		java.sql.ResultSet rs = st.executeQuery(sql);
		while(rs.next())
		{
			
			friendlist.put(String.valueOf(++i),rs.getString(1));
			
		}
		
	 sql = "SELECT username FROM users where (NOT username in (Select receivername from friend where sendername = "+sendername+")) AND (NOT username = "+sendername+");";
	 rs = st.executeQuery(sql);
	  i=0;
	 while(rs.next())
		{
			otherlist.put(String.valueOf(++i),rs.getString(1));
		}
		
	 
	 sql = "SELECT sendername from request where receivername = "+sendername+";";
	 rs = st.executeQuery(sql);
	 i=0;
	 while(rs.next())
	 {
		requestlist.put(String.valueOf(++i),rs.getString(1));  
		 
	 }
	 
	 con.close();
		
		
	listOfUser.put("friendList", friendlist);
	
	listOfUser.put("otherlist", otherlist);
	listOfUser.put("requestlist", requestlist);
	 
		return listOfUser.toString();
		
		}
		catch(Exception e)
		{
			System.out.println("error in query\n"+e.toString());
			return listOfUser.toString();
		}
}
	
	/*private String convertToString(List<String> list)
	{
	
		
		if(list.size()==0)
			
			return "0";
		
		java.util.Iterator iterator = list.iterator();
		
		String stringObject="";
		while(iterator.hasNext())
		{
			
			String result =(String)iterator.next(); 
			stringObject +=result+" \n ";
			
		}
		return stringObject;
		
		
	}*/

}
