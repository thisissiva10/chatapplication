package texter;

import java.sql.Connection;
import java.util.Map;

import org.apache.struts2.dispatcher.SessionMap;
import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionSupport;

public class Validation extends ActionSupport implements SessionAware 
{

	@Override
	public void validate() 
	{
	
		if(getUsername()==null || getPassword()==null)
		{
			result="null";
		}
		
		else if(getUsername().trim().equals(""))
		{
			addFieldError("username","spaces are not allowed");  
		}
		else if(getPassword().trim().equals(""))
		{
			addFieldError("password","password can't be blank");  
		}

	}

	private SessionMap<String,String> session;
	private  String username;
	private  String password;
	private  String result="success"; 
	
	
  public String getUsername() {
		return username;
	}


 
	public void setUsername(String username) {
		this.username = username;
	}



	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public void setSession(Map<String, Object> arg0) {
		// 
		
		session=(SessionMap) arg0;
		
	}

	public  String execute()
	{
		
		
		if(result.equals("null"))
			return result;
		
		try
		{
			//System.out.println("actual user name :"+ username);
			Connection con = new ConnectionManager().getConnection();
			java.sql.Statement st = con.createStatement();
			String sql = "SELECT username,password FROM users;"; 
			java.sql.ResultSet rs = st.executeQuery(sql);
			
			while(rs.next())
			{
			String rusername = rs.getString(1);
			String rpassword = rs.getString(2);
			if(rusername.equals(username) && rpassword.equals(password))
			{
				session.put("username",username);
				//session.setUsername(username);
				username="'"+username+"'";
               	sql = "update users set login = true where username = "+username+";";			
				st.execute(sql);
				
				con.close();
				return "success";
			}
			
			}
						
			con.close();
			return "failure";
			
		}
		catch(Exception e)
		{
			
			e.printStackTrace();
			return "failure";
		}
		
		//return "success";
		
	}
			
	
}
