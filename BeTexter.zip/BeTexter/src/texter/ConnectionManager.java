//$Id$
package texter;

import java.sql.Connection;
import java.sql.DriverManager;


public class ConnectionManager {
public Connection getConnection()   {

	try{
	Connection con=null;
	Class.forName("com.mysql.jdbc.Driver");
	con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/betexter","root","");
	return con;
	}
	
catch(Exception e)
	{
	return null;
	}
	}

}
