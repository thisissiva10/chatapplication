package texter;

import java.sql.Connection;

import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

public class CancelReq 
{

	public String cancelRequest(String touser)
	{
	
		touser = "'"+touser+"'";
		HttpSession sessionObject=ServletActionContext.getRequest().getSession(false); 
		String sendername = String.valueOf(sessionObject.getAttribute("username"));
		sendername = "'"+sendername+"'";
	
		try
		{
			Connection con = new ConnectionManager().getConnection();
			java.sql.Statement st = con.createStatement();
			String sql = "DELETE FROM friend WHERE (sendername = "+sendername+" AND receivername = "+touser+") OR (sendername = "+touser+" AND receivername = "+sendername+" );";
			st.execute(sql);
			sql = "UPDATE users SET notify = true where username in ("+touser+","+sendername+");";
			st.execute(sql);
			con.close();		
			return "success";
			
		}
		catch(Exception e)
		{
			System.out.println(e);
			return "failure";
			
		}
		
		
	}
	
	
	
} 
