package texter;

import java.sql.Connection;

public class AddToRecords
{
	
	private String username;
	private String password;
	private String name;
	private String confirmpassword;
	
	public String getConfirmpassword() {
		return confirmpassword;
	}
	public void setConfirmpassword(String confirmpassword) {
		this.confirmpassword = "'"+confirmpassword+"'";
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = "'"+username+"'";
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = "'"+password+"'";
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = "'"+name+"'";
	}
	

	public String execute()
	{
		if(!getPassword().equals(getConfirmpassword()))
			return "notsame";
		
		try
		{
			Connection con = new ConnectionManager().getConnection();
			java.sql.Statement st = con.createStatement();
			
		String sql = "INSERT INTO users(username,password,name,login,friendcount) VALUES("+getUsername()+","+getPassword()+","+getName()+", true,0);";
		st.execute(sql);
		con.close();
			return "success";
		
		
		
		}catch(Exception e)
		{
			System.out.println(e);
			return "failure";
		}
		
	}

}
